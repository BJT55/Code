package com.sust.service;

import java.util.List;

import com.sust.entity.Users;

/**
 * 
 * @author 臧梦佳
 *
 */
public interface IUserService {

	public int regist(Users user) throws Exception;

	public int removeUserByUserid(Integer userid) throws Exception;

	public int modifyUserByUserid(Users user) throws Exception;

	public Users login(String username, String password) throws Exception;

	public List<Users> getAllUsers() throws Exception;

	public int modifyUserState(Users user) throws Exception;
}
