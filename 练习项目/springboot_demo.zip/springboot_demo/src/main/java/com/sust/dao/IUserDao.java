package com.sust.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.sust.entity.Users;

/**
 * 
 * @author 臧梦佳
 *
 */
@Mapper // 标记当前类为一个功能映射类（组件）
public interface IUserDao {
	@Insert("insert into users (username,password,sex) values(#{username},#{password},#{sex})")
	public int regist(Users user) throws Exception;
	
	@Delete("delete from users where userid=#{userid}")
	public int removeUserByUserid(Integer userid) throws Exception;

	@Update("update users set password=#{password} where userid=#{userid}")
	public int modifyUserByUserid(Users user) throws Exception;

	@Select("select * from users where username=#{username} and password=#{password}")
	public Users login(@Param("username") String username, @Param("password") String password) throws Exception;

	@Select("select * from users")
	public List<Users> getAllUsers() throws Exception;

	@Update("update users set state=#{state} where userid=#{userid}")
	public int modifyUserState(Users user) throws Exception;
	
}