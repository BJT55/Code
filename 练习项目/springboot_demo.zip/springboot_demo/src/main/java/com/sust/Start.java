package com.sust;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@SpringBootApplication//标记当前类为springboot的启动类
@Controller//通过根目录找到当前类
@MapperScan("com.sust")  //包扫描--系统启东市扫描sust的所有包
public class Start {
	
	public static void main(String[] args) {
		System.out.println("开始....");
		SpringApplication.run(Start.class,args);
		System.out.println("结束....");
	}
	
	@RequestMapping("/say")
	@ResponseBody   // 通过/user
	public String sayHello() {
		System.out.println("hello");
		return "hello,this is my Springboot...";
	}
	
	
	@RequestMapping("/index")
	public String toLogin(){
		System.out.println("");
		return "index";
	}
	
	@RequestMapping("/admin")
	public String admin(){
		System.out.println("toLogin...");
		return "admin_Login";
	}

}