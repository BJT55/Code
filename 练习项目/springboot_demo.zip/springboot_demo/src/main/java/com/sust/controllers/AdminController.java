package com.sust.controllers;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sust.entity.Users;
import com.sust.service.impl.UserServiceImpl;

@Controller // 控制器 --servlet
@RequestMapping("/admin") // 通过/user这个字符串找到UserController这个类
public class AdminController {
	private Logger log = Logger.getLogger(AdminController.class); // log4j日志

	@Autowired // 按类型匹配
	private UserServiceImpl userService;

	@RequestMapping("/login")
	public String login(String username, String password, Map<String, Object> map, HttpSession session)
			throws Exception {
		Users user = userService.login(username, password);
		if (user != null && "管理员".equals(user.getRole())) {
			session.setAttribute("user", user);
			List<Users> userList = userService.getAllUsers();
			map.put("userList", userList);
			return "showAllUsers";
		} else {
			map.put("loginDefeat", "用户名称或密码不正确，请重新输入");
			return "admin_Login";
		}

	}

	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "admin_Login";
	}

	@RequestMapping("/modifyPassword/{id}")
	public String modifyPassword(@PathVariable("id") Integer id, Map<String, Object> map) throws Exception {
		Users user = new Users();
		user.setUserid(id);
		int num = userService.modifyUserByUserid(user);
		if (num > 0) {
			map.put("flag", "修改成功");
		} else {
			map.put("flag", "修改失败");
		}
		List<Users> userList = userService.getAllUsers();
		map.put("userList", userList);
		return "showAllUsers";

	}

	@RequestMapping("/modifyUserState")
	public String modifyUserState(Integer userid, String state, Map<String, Object> map) throws Exception {
		Users user = new Users();
		user.setUserid(userid);
		user.setState(state);
		userService.modifyUserState(user);
		List<Users> userList = userService.getAllUsers();
		map.put("userList", userList);

		return "showAllUsers";
	}
	
	@RequestMapping("/removeUserByUserid/{id}")
	public String removeUserByUserid(@PathVariable("id") Integer id, Map<String, Object> map) throws Exception {
		int num = userService.removeUserByUserid(id);
		if (num > 0) {
			map.put("delete", "删除成功");
		} else {
			map.put("delete", "删除失败");
		}
		List<Users> userList = userService.getAllUsers();
		map.put("userList", userList);
		return "showAllUsers";
	}

}