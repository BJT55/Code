package com.sust.controllers;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sust.entity.Users;
import com.sust.service.impl.UserServiceImpl;


@Controller // 控制器 --servlet
@RequestMapping("/user") // 通过/user这个字符串找到UserController这个类
public class UserController {
	private Logger log = Logger.getLogger(UserController.class); // log4j日志

	@Autowired // 按类型匹配
	private UserServiceImpl userService;

	// @RequestMapping("/index") // 通过/index这个字符串找到index这个方法
	// public String index() {
	// System.out.println("index...");
	// return "index"; // 逻辑地址--视图名称 ---默认为请求转发
	// }

	@RequestMapping("/toRegist")
	public String toRegist() {

		return "regist";
	}

	@RequestMapping("/toLogin")
	public String toLogin() {
		return "login";
	}

	@RequestMapping("/regist")
	public String regist(Users user, Map<String, Object> map) throws Exception { // 数据绑定---对象绑定
		log.info("用户信息为：" + user);
		try {
			int num = userService.regist(user);
			if (num > 0) {
				return "login";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		map.put("registDefeat", "用户名已存在，注册失败");
		return "regist";
	}

	@RequestMapping("/login")
	public String login(String username, String password, Map<String, Object> map, HttpSession session)
			throws Exception {
		Users user = userService.login(username, password);
		log.info("....." + user);
		if (user != null && user.getUserid() > 0) {
			if ("false".equals(user.getState())) {
				map.put("loginDefeat", "账号已经被禁用，请与管理员联系");
				return "login";
			}
			session.setAttribute("user", user);
			return "success";
		} else {
			map.put("loginDefeat", "用户名称或密码不正确，请重新输入");
			return "login";
		}

	}

}
