package com.sust.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sust.dao.IUserDao;
import com.sust.entity.Users;
import com.sust.service.IUserService;
import com.sust.utils.MD5;


/**
 * 
 * @author 臧梦佳
 *
 */
@Service
public class UserServiceImpl implements IUserService {
	@Autowired
	private IUserDao userDao; // 依赖注入

	@Override
	public int regist(Users user) throws Exception {
		String newPass = new MD5().getMD5ofStr(user.getPassword());
		user.setPassword(newPass);
		return userDao.regist(user);
	}

	@Override
	public int removeUserByUserid(Integer userid) throws Exception {

		return userDao.removeUserByUserid(userid);
	}

	@Override
	public int modifyUserByUserid(Users user) throws Exception {
		String newPass = new MD5().getMD5ofStr("88888888");
		user.setPassword(newPass);
		return userDao.modifyUserByUserid(user);
	}

	@Override
	public Users login(String username, String password) throws Exception {

		String newPass = new MD5().getMD5ofStr(password);

		return userDao.login(username, newPass);
	}

	@Override
	public List<Users> getAllUsers() throws Exception {

		return userDao.getAllUsers();
	}

	@Override
	public int modifyUserState(Users user) throws Exception {
		if ("true".equals(user.getState())) {
			user.setState("false");
		} else {
			user.setState("true");
		}
		return userDao.modifyUserState(user);
	}
}

