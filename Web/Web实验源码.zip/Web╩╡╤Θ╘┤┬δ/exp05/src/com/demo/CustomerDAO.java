package com.demo;
import java.sql.*;
public class CustomerDAO {
	private Connection con;
	public CustomerDAO() 
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/test";
			con=DriverManager.getConnection(url,"root","0112.zmj");
		}
		catch(Exception e) 
		{
			
		}
	}
	public boolean insertCustomer(CustomerBean customer) throws SQLException 
	{
		Statement st=con.createStatement();
		String sql="insert into customer values('"+customer.getCustName()+"','"+customer.getEmail()+"','"
				+customer.getPhone()+"')";
		boolean rs=st.execute(sql);
		if(!rs) 
		{
			return true;
		}
		return false;
	}
}