package com.demo;

import java.sql.*;

public class BookDAO {
	private static  Connection con;	
	public BookDAO() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/test";
			 con=DriverManager.getConnection(url,"root","0112.zmj");
		}
		catch(Exception e) {}
	}
  public ResultSet result() throws ClassNotFoundException, SQLException 
	{
   	   Statement stmt=con.createStatement();
   	    String sql="select * from book";
   	    ResultSet rs=stmt.executeQuery(sql);
		return rs;
	}
  
	public static   String bookid(int i)throws SQLException 
	{
		
		Statement stmt=con.createStatement();
	    String sql="select * from book";
	    ResultSet rs=stmt.executeQuery(sql);
	    BookBean book=new BookBean();
		String result="";
		try 
		{
		    int rowCount=0;
		    while(rs.next()) 
		       {
		    	rowCount++;
		    	    if(rowCount==i)
		    	    {
		    	    	book.setBookid(rs.getString(1));
			    		result=book.getBookid();
			    		System.out.print(result);
			    		break;
		    	    }
		    	
			   }
		    //conn.close();
		}catch(Exception e) 
		{}
		return result;
		
	}
	public boolean insertBook(BookBean book) throws SQLException
	{
		Statement st=con.createStatement();
		String sql="insert into book values('"+book.getBookid()+"','"+book.getTitle()+"','"+book.getAuthor()+"','"+book.getPublisher()+"',"+book.getPrice()+")";
	    boolean rs=st.execute(sql);
		if(!rs) 
		{
			return true;
		}
		return false;
	}
	public  BookBean searchBook(String bookid) throws SQLException, ClassNotFoundException 
	{
		BookBean bookbean=new BookBean();
		Statement st=con.createStatement();
		String sql="select * from book where bookid="+bookid;
		ResultSet rs=st.executeQuery(sql);
		if(rs.next()) 
		{
				bookbean.setBookid(rs.getString(1));
				bookbean.setTitle(rs.getString(2));
				bookbean.setAuthor(rs.getString(3));
				bookbean.setPublisher(rs.getString(4));
				bookbean.setPrice(rs.getFloat(5));
		}else 
		{
			return null;
		}
		return bookbean;
	
	}
}