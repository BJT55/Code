package com.beans;

public class SimpleCalculator {
	private float first;
	private float second;
	private String operator;
	private float result;
	public SimpleCalculator() {}
	
	public float calculator() {
		try {
			switch(operator) {
			case "+":
				result = first + second;
				break;
			case "-":
				result = first - second;
				break;
			case "*":
				result = first * second;
				break;
			case "/":
				result = first / second;
				break;
			default:
				System.out.println("�������������,����������...");
				break;
			}
		}catch (Exception e) {
			e.getStackTrace();
		}
		return result;
	}

	public float getFirst() {
		return first;
	}

	public void setFirst(float first) {
		this.first = first;
	}

	public float getSecond() {
		return second;
	}

	public void setSecond(float second) {
		this.second = second;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public float getResult() {
		return result;
	}

	public void setResult(float result) {
		this.result = result;
	}
	
	

}
