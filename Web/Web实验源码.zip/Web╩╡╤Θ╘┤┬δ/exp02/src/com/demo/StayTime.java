package com.demo;
import java.util.Date;

public class StayTime {
	private int hour = 0;
	private int minute = 0;
	private int second = 0;
	public StayTime() {}
	public void countTime(Date startTime) {
		Date endTime = new Date();
		long stayTime = endTime.getTime() - startTime.getTime();
		hour = (int)(stayTime / 1000 / 60 / 60);
		stayTime = stayTime - hour * 60 * 60 * 1000;
		minute = (int) (stayTime / 1000 / 60);
		stayTime = stayTime - minute * 60 * 1000;
		second = (int)( stayTime / 1000);
	}
	public int getHour() {
		return this.hour;
	}
	public int getMinute() {
		return this.minute;
	}
	public int getSecond() {
		return this.second;
	}
}
