package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class GuessNumberServlet
 */
@WebServlet("/GuessNumberServlet")
public class GuessNumberServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public GuessNumberServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int magic = (int)(Math.random()*101);
		HttpSession session = request.getSession();
		session.setAttribute("num", new Integer(magic));
		
		response.setContentType("text/html;charset = UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		out.println("���һ��0��100֮�����:");
		out.println("<form action='/exp04/GuessNumberServlet' method='post'>");
		out.println("<input type = 'text' name = 'guess'/>");
		out.println("<input type = 'submit' value = 'ȷ��'/>");
		out.println("</form></body></html>");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int guess = Integer.parseInt(request.getParameter("guess"));
		HttpSession session = request.getSession();
		int magic = (Integer)session.getAttribute("num");
		
		response.setContentType("text/html;charset=UTF-8"); 
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		if(guess == magic) {
			out.println("��ϲ��,�����!");
			out.println("<a href='/exp04/GuessNumberServlet'>���ٲ�һ�ΰ�~~</a>");
		}else if(guess > magic) {
			out.println("�²�ֵ����,���ز�...");
		}else {
			out.println("�²�ֵС��,���ز�...");
		}
		out.println("<a href = '/exp04/GuessNumberServlet' method = 'post'>");		
		out.println("<br><input type = 'text' name = 'guess'/>");
		out.println("<input type = 'submit' value = 'ȷ��'/>");
		out.println("</from></body></html>");
	}
}
