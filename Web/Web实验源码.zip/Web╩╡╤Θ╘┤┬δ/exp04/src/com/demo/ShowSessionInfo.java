package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ShowSessionInfo
 */
@WebServlet("/ShowSessionInfo")
public class ShowSessionInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public ShowSessionInfo() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset = UTF-8");
		HttpSession session = request.getSession(true);
		String heading = null;
		String info = "Information about your session";
		Integer accessCount = (Integer) session.getAttribute("accessCount");
		if(accessCount == null) {
			accessCount = new Integer(1);
			heading = "Welcome Back!";
		}else {
			accessCount = accessCount+1;
			heading = "Welcome Back.";
		}
		session.setAttribute("accessCount", accessCount);
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<body><center><h2>"+heading+"<a href='showsession.do'></a>"+"</h2>"+"<h3>"+info+"</h3>");
		out.println("<table border = '0'>");
		out.println("<tr bgcolor=\"ffad0\"><td>Info Type</td><td>Value\n");
		out.println("<tr><td>ID:<td>"+session.getId()+"\n");
		out.println("<tr><td>Creation Time:<td>");
		out.println(session.getCreationTime()+"\n");
		out.println("<tr><td>Time of last access:<td>");
		out.println(session.getLastAccessedTime()+"\n");
		out.println("<tr><td>Access number:<td>"+accessCount+"\n");
		out.println("</table>");
		out.println("</center></body></html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
