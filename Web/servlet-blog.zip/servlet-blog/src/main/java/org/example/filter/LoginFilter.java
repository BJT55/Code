package org.example.filter;

import org.example.model.JSONResponse;
import org.example.model.User;
import org.example.util.JSONUtil;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter("/*")
public class LoginFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        String servletPath = req.getServletPath();

            // 前端敏感资源
        if (servletPath.startsWith("/jsp/")){
            if (isLogin(req)){ // 登录允许访问
                chain.doFilter(request,response);
            }else { // 未登录,跳转到登录界面
                String scheme = req.getScheme(); //http
                String host = req.getServerName(); // ip/域名
                int port = req.getServerPort(); // port
                String contextPath = req.getContextPath(); //应用上下文路径
                String basePath = scheme + "://" + host + "/" + port + "/" + contextPath;
//                resp.sendRedirect();
            }
            // 后端敏感资源
        }else if (!servletPath.startsWith("/static/") &&
                    !servletPath.equals("/login.html") &&
                    !servletPath.equals("login")){  // else if已排除前端敏感资源,条件逻辑排除前端/后端公开资源

            if (!isLogin(req)){ // 未登录,返回401状态码,响应体是json
                resp.setStatus(401);
                JSONResponse json = new JSONResponse();
                json.setCode("LOG000");
                json.setMessage("用户未登录,不允许操作");
                resp.getWriter().println(JSONUtil.serialize(json));
                return;
            }
        }
    }

    public static boolean isLogin(HttpServletRequest req){
        HttpSession session = req.getSession();
        if (session != null) {
            User user = (User) session.getAttribute("user");
            if (user != null){
                return true; // 有session并且有保存的用户信息
            }
        }
        return false;
    }

    @Override
    public void destroy() {

    }
}
